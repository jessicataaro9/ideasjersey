<!DOCTYPE HTML>
<html>
    <head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    	<title>Instagram Authentication</title>
    	<script type="text/javascript">
    		if(location.href.search('error') > -1) {
				self.close();
			}
    	</script>
    </head>
    <body>
    </body>
</html>